import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GuessGame implements ActionListener {

	private JTextField num;
	private JLabel resultLabel;
	private JButton guess;
	private Random r;
	private int random;
	private int result;

	private void addComponentsToPane(Container pane) {
		JLabel label = new JLabel();
		resultLabel = new JLabel("", SwingConstants.CENTER);
		num = new JTextField();
		guess = new JButton("Guess");

		pane.setLayout(new GridLayout(4, 1));
		label.setText("I have a number between 1 and 1000, "
				+ "can you guess my number?");
		guess.addActionListener(this);

		JPanel buttonLayout = new JPanel();
		buttonLayout.add(guess);
		guess.setPreferredSize(new Dimension(150, 30));

		generate();

		pane.add(label);
		pane.add(num);
		pane.add(buttonLayout);
		pane.add(resultLabel);

	}

	public void play() {
		JFrame frame = new JFrame("Guessing Game");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addComponentsToPane(frame.getContentPane());
		frame.pack();
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() instanceof JButton) {
			verify();
		}
	}

	
	/**
	 * Checks if you guessed the random number.  If you guessed the number,
	 * textfield and button is disabled. If not, a hint about hit percentage
	 * will display.
	 */
	private void verify() {
		int input = Integer.parseInt(num.getText().trim());
		result = 0;

		if (random == input) {
//			System.out.println("got it!");
			num.setEnabled(false);
			guess.setEnabled(false);
			resultLabel.setText("You Got It!");
			generate();

		} else if (random > input) {
			result = (input * 100) / random;
			hit();

		} else if (random < input) {
			result = ((input - random) * 100) / (1000 - random);
			result = (result - 100) * -1;
			hit();
		}

	}

	private void generate() {
		r = new Random();
		random = r.nextInt(1000);
//		System.out.println(random);
	}

	private void hit() {
		if ((result == 100) && (result != random)) {
			resultLabel.setText("You're Almost There!");
		} else
			resultLabel.setText(Integer.toString(result) + "% hit");
	}

} // end of GuessGame
